
package proyectof;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import java.util.Stack;

import javax.swing.JOptionPane;

public class ProyectoF {

    public static ArrayList<Transportadora> listatransp = new ArrayList();
    public static ArrayList<Transportadora> cerrarcarga = new ArrayList();
    public static Stack<Transportadora> pila = new Stack();

    public static void main(String[] args) {
        InteCarga  c = new InteCarga(); 
        c.setVisible(true);
    }
    // Cadastra primer  Array
    // Registra cragas
    public Object Cadastro(String nomeEnvio, String nomeDestino, float Volume, float distancia) {

        listatransp.add(new Transportadora(nomeEnvio, nomeDestino, Volume, distancia));
        return null;

    }
    //muestra Array de los productos de arriba
    public String Registrar() {
        String st1 = "";

        for (Transportadora t : listatransp) {

            for (int i = 0; i < listatransp.size(); i++) {
                int y = 0;
                y++;

                st1 += i + ")Remitente: " + listatransp.get(i).getNomeRemetente() + "\n" + "Destinatario: "
                        + listatransp.get(i).getNomeClienteDestino() + "\n"
                        + "Volumen carga: " + listatransp.get(i).getVolumeCarga()
                        + "\n" + "Distancia km: " + listatransp.get(i).getDistancaoCidadeDestino() + "\n\n";

            }
            return "" + st1;
        }

        return null;
    }
    
        //Grava o primero array no archivo csv
    public String GrabarAchivo() throws IOException {
        File arquivo = new File("CargasRecebidas.csv");
        FileWriter fw = new FileWriter(arquivo, false);
        BufferedWriter bw = new BufferedWriter(fw);
        for (Transportadora l : listatransp) {
            bw.write(l.getNomeRemetente() + ";");
            bw.write(l.getNomeClienteDestino() + ";");
            bw.write(l.getVolumeCarga() + ";");
            bw.write(l.getDistancaoCidadeDestino() + ";");
            
            

            bw.newLine();
        }
        bw.close();
        fw.close();
        return null;
    }
    //Cierra la carga y pasa para otro Array
    //Pasa carga volumen =< 50
    
    public String CerrarCarga() throws IOException {
        float total = 50;
        Transportadora tt = new Transportadora();
        float acu = 0;
        for (int i = 0; i < listatransp.size();) { //deposito

            if (acu + listatransp.get(i).getVolumeCarga() <= total) {
                acu = acu + listatransp.get(i).getVolumeCarga();
                cerrarcarga.add(listatransp.get(i));
                
               listatransp.remove(i);

            } else {
              
              i++;
              
            }

            File arquivo = new File("Caminhao.csv");
            FileWriter fw = new FileWriter(arquivo, false);
            BufferedWriter bw = new BufferedWriter(fw);
            for (Transportadora l : cerrarcarga) {
                bw.write(l.getNomeRemetente() + ";");
                bw.write(l.getNomeClienteDestino() + ";");
                bw.write(l.getVolumeCarga() + ";");
                bw.write(l.getDistancaoCidadeDestino() + ";");
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
       
              

        /// Muetra la lista que en el camion
        String st1 = "";
     
        for (Transportadora t : cerrarcarga) {

            for (int i = 0; i < cerrarcarga.size(); i++) {
                int y = 0;
                y++;

                st1 += "Remitente: " + cerrarcarga.get(i).getNomeRemetente() + "\n" + "Destinatario: "
                        + cerrarcarga.get(i).getNomeClienteDestino() + "\n"
                        + "Volume carga: " + cerrarcarga.get(i).getVolumeCarga()
                        + "\n" + "Distancia km: " + cerrarcarga.get(i).getDistancaoCidadeDestino() + "\n\n";
              
            }
                    

           JOptionPane.showMessageDialog(null, st1 + "\n" + "Volumen total " + acu );
            
            return "" + st1;
        }
        return null;
    }

    

    //Muestra Pila final de la segunda parte del proyecto
    public String mostrarPila() {
        String st1 = "";

        for (Transportadora t : pila) {

            for (int i = 0; i < pila.size(); i++) {
                int y = 0;
                y++;

                st1 += i + ") Remitente: " + pila.get(i).getNomeRemetente() + "\n" + "Destinatario: "
                        + pila.get(i).getNomeClienteDestino() + "\n"
                        + "Volumen carga: " + pila.get(i).getVolumeCarga()
                        + "\n" + "Distancia km:" + pila.get(i).getDistancaoCidadeDestino() + "\n\n";
                
            }
            
            return "" + st1;

        }
        return "Encomiendas descargadas!";
    }
    //Descarga por distancia km 
    
    public String DescargaPila(float distancia) {
        
        for (int i = 0; i < pila.size(); i++) {
            if (pila.peek().getDistancaoCidadeDestino() == distancia) {
                pila.pop();

            }
            else return "Encomiendas cargadas!";

       }
        return null;

    }
    //Grava el array de cuando fecha camion en achivo text
    
    public float GravaArchivoPila() throws IOException {
        File arquivo = new File("archivoPilas.txt");
        FileWriter fw = new FileWriter(arquivo, false);
        BufferedWriter bw = new BufferedWriter(fw);
        float distancia = 400;
        for (Transportadora l : cerrarcarga) {
            if (l.getDistancaoCidadeDestino() == distancia) {

                bw.write(l.getNomeRemetente() + ";");
                bw.write(l.getNomeClienteDestino() + ";");
                bw.write(l.getVolumeCarga() + ";");
                bw.write(l.getDistancaoCidadeDestino() + ";");
                bw.newLine();
            }
        }

        distancia = 340;
        for (Transportadora l : cerrarcarga) {
            if (l.getDistancaoCidadeDestino() == distancia) {

                bw.write(l.getNomeRemetente() + ";");
                bw.write(l.getNomeClienteDestino() + ";");
                bw.write(l.getVolumeCarga() + ";");
                bw.write(l.getDistancaoCidadeDestino() + ";");
                bw.newLine();
            }
        }

        distancia = 180;
        for (Transportadora l : cerrarcarga) {
            if (l.getDistancaoCidadeDestino() == distancia) {

                bw.write(l.getNomeRemetente() + ";");
                bw.write(l.getNomeClienteDestino() + ";");
                bw.write(l.getVolumeCarga() + ";");
                bw.write(l.getDistancaoCidadeDestino() + ";");
                bw.newLine();
            }
        }
        bw.close();
        fw.close();

        return 0;

    }
    //lee achivo y pasa para pila en orden descrecnte
    
    public float LeerPila() throws IOException {
        File arquivo = new File("archivoPilas.txt");
        FileReader fr = new FileReader(arquivo);
        BufferedReader br = new BufferedReader(fr);
        while (br.ready()) {
            String[] t = br.readLine().split(";");

            String nome = t[0];
            String nome2 = t[1];
            float volume = Float.parseFloat(t[2]);
            float distancia = Float.parseFloat(t[3]);

            pila.push(new Transportadora(nome, nome2, volume, distancia));
        }
        fr.close();
        return 0;

    }
    
} 
